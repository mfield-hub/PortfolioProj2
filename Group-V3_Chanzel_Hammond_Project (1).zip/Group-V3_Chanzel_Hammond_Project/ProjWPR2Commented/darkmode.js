document.addEventListener("DOMContentLoaded", function () {
	console.log("Dark mode script loaded!");

	
	const isDarkMode = localStorage.getItem("darkMode") === "true";


	if (isDarkMode) {
		document.body.classList.add("dark-mode");
	}

	
	const darkModeToggle = document.getElementById("dark-mode");
	if (darkModeToggle) {
		darkModeToggle.checked = isDarkMode;

		darkModeToggle.addEventListener("change", function () {
			document.body.classList.toggle("dark-mode", darkModeToggle.checked);
			localStorage.setItem("darkMode", darkModeToggle.checked);
		});
	}
});