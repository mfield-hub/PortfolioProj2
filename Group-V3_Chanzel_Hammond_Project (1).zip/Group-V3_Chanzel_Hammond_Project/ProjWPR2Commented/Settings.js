document.addEventListener("DOMContentLoaded", function () {
    console.log("Settings page loaded!");
	const darkModeToggle = document.getElementById("dark-mode");
    const workoutRemindersToggle = document.getElementById("workout-reminders");
    const goalAlertsToggle = document.getElementById("goal-alerts");
    const saveButton = document.getElementById("save-settings");

	function loadSettings() {
        darkModeToggle.checked = localStorage.getItem("darkMode") === "true";
        workoutRemindersToggle.checked = localStorage.getItem("workoutReminders") === "true";
        goalAlertsToggle.checked = localStorage.getItem("goalAlerts") === "true";

		if (darkModeToggle.checked) {
            document.body.classList.add("dark-mode");
        }
    }

	loadSettings();

	saveButton.addEventListener("click", function () {
        localStorage.setItem("darkMode", darkModeToggle.checked);
        localStorage.setItem("workoutReminders", workoutRemindersToggle.checked);
        localStorage.setItem("goalAlerts", goalAlertsToggle.checked);

        alert("Settings saved successfully!");
    });

	document.addEventListener("DOMContentLoaded", function () {
		console.log("Dark mode script loaded!");
	
		
		const isDarkMode = localStorage.getItem("darkMode") === "true";
	
	
		if (isDarkMode) {
			document.body.classList.add("dark-mode");
		}
	
		
		const darkModeToggle = document.getElementById("dark-mode");
		if (darkModeToggle) {
			darkModeToggle.checked = isDarkMode;
	
			darkModeToggle.addEventListener("change", function () {
				document.body.classList.toggle("dark-mode", darkModeToggle.checked);
				localStorage.setItem("darkMode", darkModeToggle.checked);
			});
		}
	});
	
	function sendWorkoutReminder() {
        if (workoutRemindersToggle.checked) {
            alert("⏰ Time to log your workout!");
        }
    }

    
    function checkGoalProgress() {
        if (goalAlertsToggle.checked) {
            alert("🎯 Keep going! You're making great progress toward your fitness goals!");
        }
    }

   
    setInterval(() => {
        sendWorkoutReminder();
        checkGoalProgress();
    }, 30000); // Every 30 seconds (change to 86400000 for 1-day intervals)
});