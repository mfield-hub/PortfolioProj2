document.addEventListener('DOMContentLoaded', function() {
    let workouts = JSON.parse(localStorage.getItem("workouts")) || [];

    // Prepare data for bar and pie charts
    let workoutTypes = ["Running", "Cycling", "Strength Training", "Walking", "Swimming"];
    let workoutCounts = [0, 0, 0, 0, 0];
    let caloriesBurned = [0, 0, 0, 0, 0];

    workouts.forEach(workout => {
        let index = workoutTypes.indexOf(workout.type);
        if (index !== -1) {
            workoutCounts[index] += 1;
            caloriesBurned[index] += parseInt(workout.calories);
        }
    });

    // Bar Graph - Number of Workouts Per Type
    const barCtx = document.getElementById('barGraphCanvas').getContext('2d');
    new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: workoutTypes,
            datasets: [{
                label: 'Number of Workouts',
                data: workoutCounts,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Pie Chart - Calories Burned Per Type
    const pieCtx = document.getElementById('pieChartCanvas').getContext('2d');
    new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: workoutTypes,
            datasets: [{
                label: 'Calories Burned',
                data: caloriesBurned,
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff']
            }]
        },
        options: { responsive: true }
    });
});
