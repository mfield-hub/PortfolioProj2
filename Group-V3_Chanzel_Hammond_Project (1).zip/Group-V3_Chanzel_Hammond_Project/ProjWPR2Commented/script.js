//makes sure JS script runs after html page is loaded
document.addEventListener("DOMContentLoaded", function () {
    console.log("Script loaded successfully!");//debug: confirmation that script loaded successfully
 
    // Favorite icons toggle b/w empty and full heart
    const favoriteIcons = document.querySelectorAll(".favorite");
    favoriteIcons.forEach(icon => {
        icon.addEventListener("click", function () {
            this.innerHTML = this.innerHTML === "♡" ? "❤️" : "♡";
        });
    });
 
    // Select all radio buttons (were initially checkboxes) for workout types
    const checkBoxes = document.querySelectorAll(".exercise-radio");
    checkBoxes.forEach(checkbox => {
        //load previously saved radio btn state from localStorage & restore them
        const savedState = localStorage.getItem(radio.id);
        if (savedState === "true") {
            checkbox.checked = true;
        }
    });
 //function to count exercises chosen w/ radio btns
    function updateCount() {
        let checkedCount = 0;
        checkBoxes.forEach(checkbox => {
            localStorage.setItem(checkbox.id, checkbox.checked);//saves the state of each individual radio btn("checkbox")
            if (checkbox.checked) {
                checkedCount++;
            }
        });
        localStorage.setItem("checkedCount", checkedCount);//saves total count of selected radio btns ("checkbox")
    }
 
    checkBoxes.forEach(checkbox => {
        checkbox.addEventListener("change", updateCount);//auto updates count when radio btns change
    });
    updateCount();
 //Handling of Workout Logging
 //load previous workouts
    const workoutTableBody = document.getElementById("workoutTableBody");
    let workouts = JSON.parse(localStorage.getItem("workouts")) || [];//get workouts stored in localStorage and put into JS array, if no workouts its an empty array

    //Saving Workouts to Local Storage
    function saveWorkouts() {
        localStorage.setItem("workouts", JSON.stringify(workouts));
    }

    // Add Workout Row to Table
    function addWorkoutToTable(workout, index) {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${workout.type}</td>
            <td>${workout.duration} min</td>
            <td>${workout.calories}</td>
            <td>${workout.date}</td>
            <td>${workout.heartrate} bpm</td>
            <td class="favorite" data-index="${index}">${workout.favorite ? "❤️" : "♡"}</td>
        `;
        workoutTableBody.appendChild(row);

        // Add Click Event to Favorite Button (for new rows)
        row.querySelector(".favorite").addEventListener("click", function () {
            const workoutIndex = this.getAttribute("data-index");
            workouts[workoutIndex].favorite = !workouts[workoutIndex].favorite; // Toggle favorite
            this.innerHTML = workouts[workoutIndex].favorite ? "❤️" : "♡"; // Update button
            saveWorkouts(); // Save to localStorage
        });
    }

    // Load Workouts on Page Load
    workouts.forEach((workout, index) => addWorkoutToTable(workout, index));

    // Handle Form Submission (Logging New Workout)
    const workoutForm = document.getElementById("logWorkoutForm");
    if (workoutForm) {
        workoutForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const type = document.querySelector('input[name="type[]"]:checked');
            const duration = document.getElementById("duration").value;
            const calories = document.getElementById("calories").value;
            const heartrate = document.getElementById("heartrate").value;
            const date = document.querySelector('input[name="date"]').value;

            
            if (!type || !duration || !calories || !heartrate || !date) {
                alert("Please fill in all fields.");
                return;
            }

            // Create New Workout Object
            const newWorkout = {
                type: type.value,
                duration,
                calories,
                heartrate,
                date,
                favorite: false, // Default to not favorited
            };

            workouts.push(newWorkout);
            saveWorkouts();
            addWorkoutToTable(newWorkout, workouts.length - 1);
            workoutForm.reset();
        });
    }
});
 
    
    
    // Load progress when the page loads
    
        displayProgress();
    ;
//Goal Tracking
    const goalForm = document.getElementById("goalForm");
    if (goalForm) {
        goalForm.addEventListener("submit", function (event) {
            event.preventDefault();
 
            const goalsDropdown = document.getElementById("goals");
            const goals2Dropdown = document.getElementById("goals2");
            const goals3Dropdown = document.getElementById("goals3");
            const targetValSlider = document.getElementById("targetValduration");
            const targetValDisplay = document.getElementById("durationTargetValue");
 
            targetValSlider.addEventListener("input", function () {
            targetValDisplay.textContent = targetValSlider.value;
            });
            
 //get user input
            const goal = goalsDropdown.options[goalsDropdown.selectedIndex].text;
            const exercise = goals2Dropdown.options[goals2Dropdown.selectedIndex].text;
            const targetMetric = goals3Dropdown.options[goals3Dropdown.selectedIndex].text;
            const targetValue = targetValSlider.value;
 
            if (!goal.trim() || !exercise.trim() || !targetMetric.trim() || !targetValue.trim()) {
                alert("Please select all options before submitting");
                return;
            }

const progressData = {
    goal: goal,
    exercise: exercise,
    target: `${targetValue} ${targetMetric}`};
 
            document.querySelector(".submittedgoal1").textContent = `Goal: ${goal}`;
            document.querySelector(".submittedgoal2").textContent = `Exercise: ${exercise}`;
            document.querySelector(".submittedgoal3").textContent = `Target: ${targetValue} ${targetMetric}`;

            localStorage.setItem("progress", JSON.stringify(progressData));
            // Update UI
        displayProgress();
    });
}
        ///add fxn
// Track Record Page Functionality
function displayProgress() {
    const savedProgress = JSON.parse(localStorage.getItem("progress"));
    if (savedProgress) {
        const goal1 = document.querySelector(".submittedgoal1");
        const goal2 = document.querySelector(".submittedgoal2");
        const goal3 = document.querySelector(".submittedgoal3");

        if (goal1) goal1.textContent = `Goal: ${savedProgress.goal}`;
        if (goal2) goal2.textContent = `Exercise: ${savedProgress.exercise}`;
        if (goal3) goal3.textContent = `Target: ${savedProgress.target}`;
    }
}
displayProgress();

        
    
 
    // Update Statistics
    function updateStatistics() {
        let workouts = JSON.parse(localStorage.getItem("workouts")) || [];
        let totalCalories = workouts.reduce((sum, workout) => sum + parseInt(workout.calories), 0);
        let totalDuration = workouts.reduce((sum, workout) => sum + parseInt(workout.duration), 0);
        let totalWorkouts = workouts.length;
        let avgDuration = totalWorkouts ? Math.round(totalDuration / totalWorkouts) : 0;
 
        document.getElementById("workoutslogged").textContent = totalWorkouts;
        document.querySelector(".number-container .number").textContent = totalCalories;
        document.querySelector(".number-container:nth-child(3) .number").textContent = avgDuration;
    }
 
    if (document.getElementById("workoutslogged")) {
        updateStatistics();
    }
;
//motivational quotes generate after clicking cheetah image
const quotes = [
    "Believe in yourself and all that you are.",
    "You are stronger than you think.",
    "Every day is a new opportunity to grow.",
    "Push yourself, because no one else is going to do it for you.",
    "The only limit is the one you set yourself."
];

const cheetahButton = document.getElementById('cheetah-button');
const quoteText = document.getElementById('quote');

if (cheetahButton && quoteText) {
    cheetahButton.addEventListener("click", function () {
        const randomIndex = Math.floor(Math.random() * quotes.length);
        quoteText.textContent = quotes[randomIndex];
    });

    //code for message popping up describing badges and trophy
     //tooltip element created for message pop up
     const images = document.querySelectorAll(".achievements-container img");
    
     images.forEach((img, index)=>{
         const message = document.createElement("span");
         message.style.position = "absolute";
         message.style.background = "#1E3A5F";
         message.style.color = "#fff";
         message.style.padding = "5px 10px";
         message.style.borderRadius = "5px";
         message.style.fontSize = "14px";
         message.style.display = "none"; //ensures the message is initially hidden
         document.body.appendChild(message);
     
 
 //Showing different messages based on image
 if (index === 0){
     message.textContent = "You can earn a Second Class Badge once you log a workout or submit a new goal!";
 }else if (index === 1){
     message.textContent = "You can earn a trophy when you complete a goal!";
 }else if (index === 2){
     message.textContent = "You can earn a First Class Badge by logging a workout every day for a week straight or when you are halfway with a goal";
 }
 
 img.addEventListener("mouseenter", (event)=>{
     message.style.display = "block";
     message.style.top = `${event.pageY + 10}px`;
     message.style.left = `${event.pageX + 10}px`;
 });
 
 img.addEventListener("mousemove", (event)=>{
     message.style.top = `${event.pageY + 10}px`;
     message.style.left = `${event.pageX + 10}px`;
 });
 
 img.addEventListener("mouseleave", ()=>{
     message.style.display = "none";
 });
 });
 //Updating the trophies and badges amount as they achieve goals
 let secondClassBadges = 0;
 let firstClassBadges = 0;
 let trophiesEarned = 0;
 
 // Load stored badge progress from localStorage (if available)
 const storedProgress = JSON.parse(localStorage.getItem("badgeProgress"));
 if (storedProgress) {
     secondClassBadges = storedProgress.secondClassBadges;
     firstClassBadges = storedProgress.firstClassBadges;
     trophiesEarned = storedProgress.trophiesEarned;
 }
 
 // Update displayed values
 function updateBadgeDisplay() {
     document.querySelector(".image-achievements + .amount").textContent = `${secondClassBadges} Second class Badges earned`;
     document.querySelector(".trophy-image + .amount").textContent = `${trophiesEarned} Trophies Earned`;
     document.querySelectorAll(".image-achievements")[1].nextElementSibling.textContent = `${firstClassBadges} First Class Badges earned`;
 }
 
 // Call this function after updating badge progress
 updateBadgeDisplay();

 //Earning of Badges and Trophies
 function checkBadgesAndUpdate() {
     let workoutCount = workouts.length; // Example condition for badge
     let goalComplete = checkGoalCompletion(); // Some condition to check if goal is completed
 
     if (workoutCount > 0) {
         secondClassBadges++;
     }
     if (workoutCount >= 7) {  // If the user logs workouts for a week
         firstClassBadges++;
     }
     if (goalComplete) { // If the user completes the goal
         trophiesEarned++;
     }
 
     // Save the progress to localStorage
     const badgeProgress = {
         secondClassBadges: secondClassBadges,
         firstClassBadges: firstClassBadges,
         trophiesEarned: trophiesEarned
     };
     localStorage.setItem("badgeProgress", JSON.stringify(badgeProgress));
 
     // Update display
     updateBadgeDisplay();
 }
 
 // Call this function whenever a goal is completed, or workout is logged
 checkBadgesAndUpdate();
 
 workoutForm.addEventListener("submit", function (event) {
     event.preventDefault();
 
     // Log the workout and check badges
     // Your workout logging logic here...
     
     // Update the badge counts and display after logging the workout
     checkBadgesAndUpdate();
})
 };
 
 
 
 